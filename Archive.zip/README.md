# notiformer

Real-time alerts and feature gates for your backend code.

Get notified instantly via push, email and more whenever something important happens in your app.

> ⚠️ **Server-side only.** Do not use in browser/frontend code — your API key would be exposed publicly. Use in Node.js, Express, Next.js API routes, serverless functions, etc.

---

## Install

```bash
npm install notiformer
```

---

## Quick start

```ts
import { Notiformer } from 'notiformer';

// Get your API key at https://app.notiformer.com/projects
const n = new Notiformer({
  apiKey: 'ntf_live_test', // ← replace this with your real key
});

await n.event({
  channel: 'payments',
  event: 'payment_success',
  description: '$49.00 — john@example.com',
  icon: '💳',
  notify: true,
});
```

> Running with `apiKey: 'ntf_live_test'` will print a setup message in your console explaining how to get your real key. No events will be sent until you replace it.

---

## Get your API key

1. Go to [app.notiformer.com/projects](https://app.notiformer.com/projects)
2. Create or open a project
3. Copy the API key
4. Replace `'ntf_live_test'` in your code

---

## Events

```ts
await n.event({
  channel: 'auth',            // groups related events (auto-created on first use)
  event: 'user_signup',       // machine-readable name
  description: 'New signup via Google',
  icon: '🎉',

  tags: { method: 'google', plan: 'free' }, // optional metadata
  value: '42nd user',         // optional value shown in the feed

  notify: true,   // true  → triggers push/email notifications
                  // false → silent log for analytics only
});
```

`event()` **never throws** by default. If something goes wrong it logs a warning and returns `null` — a failed notification should never crash your app.

---

## Feature Gates

Toggle features remotely from your Notiformer dashboard without redeploying.

```ts
const isEnabled = await n.gate('new-checkout-flow');

if (isEnabled) {
  // run new feature
} else {
  // run old feature
}
```

Gates are cached for 30 seconds by default to minimise API calls.

---

## Configuration

```ts
const n = new Notiformer({
  apiKey: 'ntf_live_...',          // required — from app.notiformer.com/projects

  silent: false,                   // true = no calls made (useful for local dev)
  throwOnError: false,             // true = throws instead of returning null
  onError: (err) => {              // called on any failed call
    console.error(err.message);
  },
});
```

### Silence in local development

```ts
const n = new Notiformer({
  apiKey: process.env.NOTIFORMER_API_KEY!,
  silent: process.env.NODE_ENV !== 'production',
});
```

---

## Common patterns

### Alert on unhandled errors

```ts
app.use(async (err, req, res, next) => {
  await n.event({
    channel: 'errors',
    event: 'unhandled_error',
    description: err.message,
    icon: '🔴',
    tags: { path: req.path, status: 500 },
    notify: true,
  });
  res.status(500).json({ error: 'Internal server error' });
});
```

### Track a payment

```ts
await n.event({
  channel: 'payments',
  event: 'payment_success',
  description: `${amount} — ${user.email}`,
  icon: '💳',
  value: amount,
  notify: true,
});
```

### Feature gate

```ts
app.post('/checkout', async (req, res) => {
  const useNewFlow = await n.gate('new-checkout-flow');
  return useNewFlow
    ? newCheckoutHandler(req, res)
    : legacyCheckoutHandler(req, res);
});
```

### Silent analytics (no notification)

```ts
await n.event({
  channel: 'monitoring',
  event: 'page_view',
  tags: { path: req.path },
  notify: false,  // ← no notification, just logged
});
```

---

## Requirements

- Node.js 18+ (uses native `fetch`)
- For Node 16: install `node-fetch` and polyfill `global.fetch`

---

## Links

- Dashboard: [app.notiformer.com](https://app.notiformer.com)
- Docs: [docs.notiformer.com](https://docs.notiformer.com)
